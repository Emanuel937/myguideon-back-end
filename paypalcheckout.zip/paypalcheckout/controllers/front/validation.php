<?php

class PaypalCheckoutValidationModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        if (Tools::getValue('paymentId')) {
            $paymentId = Tools::getValue('paymentId');
            $payerId = Tools::getValue('PayerID');
            $paypalService = new PaypalService();
            $result = $paypalService->executePayment($paymentId, $payerId);
            if ($result) {
                $this->context->cart->delete();
                Tools::redirect($this->context->link->getPageLink('order-confirmation', true, null, [
                    'id_cart' => $this->context->cart->id,
                    'id_module' => $this->module->id,
                    'key' => $this->context->customer->secure_key,
                ]));
            }
        }
        Tools::redirect($this->context->link->getPageLink('order', true, null, ['step' => 3]));
    }
}