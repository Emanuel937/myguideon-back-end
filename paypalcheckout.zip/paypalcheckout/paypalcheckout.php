<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Core\Payment\PaymentOption;

class PaypalCheckout extends PaymentModule
{
    public function __construct()
    {
        $this->name = 'paypalcheckout';
        $this->tab = 'payments_gateways';
        $this->version = '1.0.0';
        $this->author = 'X-studioApp';
        $this->controllers = array('validation');
        $this->is_eu_compatible = 1;
        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);

        parent::__construct();

        $this->displayName = $this->l('PayPal Checkout');
        $this->description = $this->l('Accept payments via PayPal, credit cards, and Pay Later.');
    }

    public function install()
    {
        return parent::install() &&
            $this->registerHook('paymentOptions') &&
            $this->registerHook('displayPaymentReturn') &&
            Configuration::updateValue('PAYPAL_CLIENT_ID', '') &&
            Configuration::updateValue('PAYPAL_SECRET', '');
    }

    public function uninstall()
    {
        return parent::uninstall() &&
            Configuration::deleteByName('PAYPAL_CLIENT_ID') &&
            Configuration::deleteByName('PAYPAL_SECRET');
    }

    public function getContent()
    {
        if (Tools::isSubmit('submitPaypalConfig')) {
            Configuration::updateValue('PAYPAL_CLIENT_ID', Tools::getValue('PAYPAL_CLIENT_ID'));
            Configuration::updateValue('PAYPAL_SECRET', Tools::getValue('PAYPAL_SECRET'));
        }

        return $this->renderForm();
    }

    protected function renderForm()
    {
        $form = '<form action="" method="post">
                    <label>PayPal Client ID</label>
                    <input type="text" name="PAYPAL_CLIENT_ID" value="' . Configuration::get('PAYPAL_CLIENT_ID') . '" />
                    <label>PayPal Secret</label>
                    <input type="text" name="PAYPAL_SECRET" value="' . Configuration::get('PAYPAL_SECRET') . '" />
                    <button type="submit" name="submitPaypalConfig">Save</button>
                </form>';
        return $form;
    }

    public function hookPaymentOptions($params)
    {
        $newOption = new PaymentOption();
        $newOption->setModuleName($this->name)
                  ->setCallToActionText($this->l('Pay with PayPal'))
                  ->setAction($this->context->link->getModuleLink($this->name, 'validation', [], true));
        return [$newOption];
    }
}


