<?php

class PaypalService
{
    private $clientId;
    private $secret;

    public function __construct()
    {
        $this->clientId = Configuration::get('PAYPAL_CLIENT_ID');
        $this->secret = Configuration::get('PAYPAL_SECRET');
    }

    public function executePayment($paymentId, $payerId)
    {
        $url = "https://api.paypal.com/v1/payments/payment/{$paymentId}/execute";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            "Content-Type: application/json",
            "Authorization: Bearer " . $this->getAccessToken()
        ]);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(["payer_id" => $payerId]));
        $response = curl_exec($ch);
        curl_close($ch);
        return json_decode($response, true);
    }

    private function getAccessToken()
    {
        $url = "https://api.paypal.com/v1/oauth2/token";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_USERPWD, "$this->clientId:$this->secret");
        curl_setopt($ch, CURLOPT_POSTFIELDS, "grant_type=client_credentials");
        $response = curl_exec($ch);
        curl_close($ch);
        $data = json_decode($response, true);
        return $data['access_token'] ?? null;
    }
}
